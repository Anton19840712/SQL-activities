-- Analyze your data, prepare 3-5 reports 
-- about the most valuable business questions (from your point of view) 
-- which could be resolved with information from your schema.
-- Each report is an SQL query that answers some business question. You can visualize the results
-- of your analysis by adding diagrams, charts.
-- Use window functions as much as possible during data analysis.

-- Database questions
-- Use window functions as much as possible during data analysis
-- Questions for analysis
-- Is there a relationship between the indicators of political indices and the number of revolutions?
-- Is there a relationship between membership in the CSTO, the number of protesters and the result of revolutions?
-- Who are all these people? The ratio of revolutionary-minded citizens by psychological and political class.

--1
--Is there a relationship between the indicators of political indices and the number of revolutions?
SELECT 
	cn.country_name, 
	prr.revolution_campaign_reason, 
	CASE WHEN prc.success = 1 THEN 'success' ELSE 'noresult' END as result,
	pin.functioning_of_government AS government_level, 
	pin.civil_liberties, 
	pin.political_rights,
	RANK () OVER (ORDER BY pin.functioning_of_government) government_rank,
	RANK () OVER (ORDER BY pin.civil_liberties) civil_liberties_rank,
	RANK () OVER (ORDER BY pin.political_rights) political_rights_rank,
	(RANK () OVER (ORDER BY pin.functioning_of_government)+
	RANK () OVER (ORDER BY pin.civil_liberties) +
	RANK () OVER (ORDER BY pin.political_rights)) AS resRank,
	count(*) OVER (PARTITION BY country_name) as totalAttempts
FROM political_revolution_campaigns prc
	JOIN country_names cn ON prc.country_id = cn.id
	JOIN political_indicators pin ON pin.country_id = prc.country_id
	JOIN political_revolutions_reasons prr ON prc.reason_id = prr.id
ORDER BY 
	resrank, 
	totalattempts desc, 
	cn.country_name;
	
--2
--Is there a relationship between membership in the CSTO, the number of protesters and the result of revolutions?
WITH t1 as(
SELECT 
	prc.id, 
	cn.country_name, 
	prc.begin_date, 
	prc.end_date, 
	prr.revolution_campaign_reason,
	CASE WHEN prc.success = 1 THEN 'success' ELSE 'noresult' END as revresult,
	prc.participants_max_max,
	cbmb.military_block_name,
	DENSE_RANK () OVER (ORDER BY concat((CASE WHEN prc.success = 1 THEN 'success' ELSE 'noresult' END), cbmb.military_block_name)) AS block_result_category,
	COUNT(concat((CASE WHEN prc.success = 1 THEN 'success' ELSE 'noresult' END), cbmb.military_block_name)) OVER (PARTITION BY concat((CASE WHEN prc.success = 1 THEN 'success' ELSE 'noresult' END), cbmb.military_block_name)) AS CountNumberOfrevRes_block,
	NTILE (2) OVER (ORDER BY participants_max_max) AS "few/many_participants_block_result" --many or little
FROM political_revolution_campaigns prc LEFT JOIN
	countries_by_military_block cbmb ON cbmb.country_id = prc.country_id JOIN
	country_names cn ON cn.id = prc.country_id JOIN
	political_revolutions_reasons prr ON prr.id = prc.reason_id)
SELECT 
	*, 
	NTILE (3) OVER (ORDER BY CountNumberOfrevRes_block) AS participants_block_result  
FROM t1;

--3
--Who are all these people? The ratio of revolutionary-minded citizens by psychological and political class.
SELECT pbi.gender, COUNT(*) AS "Gender counted",
       COUNT(*) FILTER (WHERE pf.dominate_feature = 'Extraversion') as "Extraversion",
       COUNT(*) FILTER (WHERE pf.dominate_feature = 'Neuroticism') as "Neuroticism",
       COUNT(*) FILTER (WHERE pf.dominate_feature = 'Openness') as "Openness",
       COUNT(*) FILTER (WHERE pf.dominate_feature = 'Agreeableness') as "Agreeableness",
       COUNT(*) FILTER (WHERE pf.dominate_feature = 'Conscientiousness') as "Conscientiousness",
       COUNT(*) FILTER (WHERE pv.political_view = 'Liberal feminism') as "Liberal feminism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Liberalism') as "Liberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Liberal socialismruen') as "Liberal socialism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Individualism') as "Individualism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Ordoliberalism') as "Ordoliberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Conservative liberalism') as "Conservative liberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Neoliberalism') as "Neoliberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Economic liberalism') as "Economic liberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Market liberalism') as "Market liberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Social liberalism') as "Social liberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Classical liberalism') as "Classical liberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'National liberalism') as "National liberalism",
       COUNT(*) FILTER (WHERE pv.political_view = 'Paleoliberalism') as "Paleoliberalism"
FROM person_basic_info pbi JOIN
     country_names cn
     ON cn.id = pbi.country_id JOIN
     persons_features pf
     ON pf.person_id = pbi.id JOIN
     political_views pv
     ON pv.person_id = pbi.id
GROUP BY gender;

